import Vue from 'vue'
import Router from 'vue-router'
import HelloWorld from '@/views/Home/Home'

Vue.use(Router)

const routes = [
  {
    path: '/',
    name: 'HelloWorld',
    component: HelloWorld
  }
]

const router = new Router({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
