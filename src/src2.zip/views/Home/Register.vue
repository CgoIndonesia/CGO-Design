<template>
  <div class="home">
    <Header />
    <div class="content">
      <b-row align-h="center">
        <div class="form-menu">
                <b-row align-h="center">
                    <b-col>
                        <p style="font-size:32px;color:#ffffff;">Merchant</p>
                    </b-col>
                </b-row>
                <b-row>
                    <b-col>
                        <div class="form">
                            <b-row align-h="center">
                                <b-col>
                                    <p>Why work with us</p>
                                </b-col>
                            </b-row>
                            <b-row align-h="center">
                                <b-col>
                                    <b-row align-h="center">
                                        <b-col md="1">
                                            <img src="@/assets/image 39.png" alt="">
                                        </b-col>
                                        <b-col md="3">
                                            <p style="text-align:left;">Manage you services without hassle. All in one app</p>
                                        </b-col>
                                        <b-col md="1">
                                            <img src="@/assets/image 40.png" alt="">
                                        </b-col>
                                        <b-col md="3">
                                            <p style="text-align:left;">Direct access to supply and demand</p>
                                        </b-col>
                                   </b-row>
                                      <b-col>
                                         <b-tabs content-class="mt-2" justified style="text-align:left;padding:20px;">
                                            <b-tab title="Individul" active>
                                              <b-form>
                                                 <b-form-group id="regitrantname" label="Registrant Name *" label-for="regitrantname">
                                                  <b-form-input
                                                    id="regitrantname"
                                                    type="text"
                                                    required
                                                  ></b-form-input>
                                                </b-form-group>
                                                 <b-form-group id="email" label="Email *" label-for="email">
                                                  <b-form-input
                                                    id="email"
                                                    type="email"
                                                    required
                                                  ></b-form-input>
                                                </b-form-group>
                                                 <b-form-group id="phonenumber" label="Phone Number *" label-for="phonenumber">
                                                  <b-form-input
                                                    id="phonenumber"
                                                    type="text"
                                                    required
                                                  ></b-form-input>
                                                </b-form-group>
                                               <b-form-group label="Service Type *">
                                                  <b-form-radio-group id="servicetype" v-model="selected" name="radio-sub-component">
                                                    <b-form-radio value="1">Sailing</b-form-radio>
                                                    <b-form-radio value="2">Tour</b-form-radio>
                                                    <b-form-radio value="3">Transportation</b-form-radio>
                                                  </b-form-radio-group>
                                                </b-form-group>
                                                 <b-form-group id="typeofship" label="Type of Ship " label-for="typeofship">
                                                  <b-form-input
                                                    id="typeofship"
                                                    type="text"
                                                    required
                                                  ></b-form-input>
                                                </b-form-group>
                                                <b-button type="submit" variant="danger" style="width:50%;margin-left:25%">register</b-button>
                                              </b-form>
                                            </b-tab>
                                            <b-tab title="Company">
                                                <b-form>
                                                 <b-form-group id="companyname" label="Company Name *" label-for="companyname">
                                                  <b-form-input
                                                    id="companyname"
                                                    type="text"
                                                    required
                                                  ></b-form-input>
                                                </b-form-group>
                                                 <b-form-group id="companyaddress" label="Company Address *" label-for="companyaddress">
                                                  <b-form-input
                                                    id="companyaddress"
                                                    type="text"
                                                    required
                                                  ></b-form-input>
                                                </b-form-group>
                                                 <b-form-group id="registrantname" label="Registrant Name *" label-for="registrantname">
                                                  <b-form-input
                                                    id="registrantname"
                                                    type="text"
                                                    required
                                                  ></b-form-input>
                                                </b-form-group>
                                                 <b-form-group id="email" label="Email *" label-for="email">
                                                  <b-form-input
                                                    id="input-4"
                                                    type="email"
                                                    required
                                                  ></b-form-input>
                                                </b-form-group>
                                                 <b-form-group id="phonenumber" label="Phone Number *" label-for="phonenumber">
                                                  <b-form-input
                                                    id="phonenumber"
                                                    type="text"
                                                    required
                                                  ></b-form-input>
                                                </b-form-group>
                                               <b-form-group label="Service Type *">
                                                  <b-form-radio-group id="servicetype" v-model="selected" name="radio-sub-component">
                                                    <b-form-radio value="1">Sailing</b-form-radio>
                                                    <b-form-radio value="2">Tour</b-form-radio>
                                                    <b-form-radio value="3">Transportation</b-form-radio>
                                                  </b-form-radio-group>
                                                </b-form-group>
                                                 <b-form-group id="typeofship" label="Type of Ship " label-for="typeofship">
                                                  <b-form-input
                                                    id="typeofship"
                                                    type="text"
                                                    required
                                                  ></b-form-input>
                                                </b-form-group>
                                                 <b-button type="submit" variant="danger" style="width:50%;margin-left:25%">register</b-button>
                                              </b-form>
                                            </b-tab>
                                         </b-tabs>
                                      </b-col>
                                </b-col>
                            </b-row>
                        </div>
                    </b-col>
                </b-row>
        </div>
      </b-row>
      <div class="image">
        <img src="@/assets/image 41.png" width="100%" />
      </div>
    </div>
    <Footer />
  </div>
</template>

<script>
// @ is an alias to /src
import Footer from '@/components/Footer.vue'
import Header from '@/components/Header.vue'

export default {
  name: 'home',
  components: {
    Footer,
    Header
  }
}
</script>
<style>
.content{
    height: 1100px;
}
.form-menu{
    position: absolute;
    margin-top: 70px;
}
.form{
    background-color: #ffffff;
    color: black;
    margin-top: 50px;
    border:#d4d9da solid 1px;
    padding: 20px;
    border-radius: 5px;
}
@media only screen and (max-width: 600px) {
.form{
    text-align: center;
  }
}
</style>
