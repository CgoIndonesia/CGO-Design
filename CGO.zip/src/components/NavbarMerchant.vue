<template>
    <div>
 <div class="card shadow-sm">
            <div class="card-body">
                <span class="dot float-right ml-4 mr-4"></span>
                <img class="img-fluid float-right" width="35" src="@/assets/msg.png">
            </div>
        </div>
</div>
</template>

<script>
export default {
    name: 'NavbarMerchant'
}
</script>